## Markov Chains
#### Functions
- main
- rank: takes a 2d array (list of lists) and returns a single sorted list by index respective to the original (follows sample data structure)

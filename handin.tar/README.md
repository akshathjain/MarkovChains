## Markov Chains
#### Functions
- main: put new test data (list of lists) in the var adjList and this will print out the rankings
- rank: takes a 2d array (list of lists) and returns a single sorted list by index respective to the original (follows sample data structure)
